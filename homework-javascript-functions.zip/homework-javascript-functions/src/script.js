var mpg12Ele =document.body.querySelector(".mpg12");
var mpg17Ele =document.body.querySelector(".mpg17");
var mpg26Ele =document.body.querySelector(".mpg26");
var mpg29Ele =document.body.querySelector(".mpg29");
var buttonEle =document.body.querySelector(".editButton");

function rewriteFunction(){
var miles =prompt("How many miles?");
var costGas =prompt("How much does gas cost?");
}

function fuelEcon(costGas, miles){
  var mpgRating12 = (12*miles)/ costGas;
  var mpgRating17 = (17*miles)/costGas;
  var mpgRating26 = (26*miles)/costGas;
  var mpgRating29 = (29*miles)/costGas;
  
  mpg12Ele.innerHTML="The fuel economy for a car with a 12 MPG rating over "+miles+" miles with  a fuel cost of $"+costGas" per gallon is "+mpgRating12;
  mpg17Ele.innerHTML="The fuel economy for a car with a 12 MPG rating over "+miles+" miles with  a fuel cost of $"+costGas" per gallon is "+mpgRating17;
  mpg26Ele.innerHTML="The fuel economy for a car with a 12 MPG rating over "+miles+" miles with  a fuel cost of $"+costGas" per gallon is "+mpgRating26;
  mpg29Ele.innerHTML="The fuel economy for a car with a 12 MPG rating over "+miles+" miles with  a fuel cost of $"+costGas" per gallon is "+mpgRating29;
};

buttonEle.addEventListener("click", function(){
  rewriteFunction();
})